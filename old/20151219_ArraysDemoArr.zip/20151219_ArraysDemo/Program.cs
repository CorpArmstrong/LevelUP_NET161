﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20151212_ArraysDemo
{
    class Program
    {
        static Random rnd = new Random();

        #region --- === ###   Одномерные массивы (векторы)   ### === ---

        // Массивы всегда передаются по ссылке, т.к. являются ссылочными типами!!!
        // !!! ссылка на массив передаётся по значению
        static void InitRandIntArr(int[] a, int minVal = -100, int maxVal = 100)
        {
            for (int i = 0; i < a.Length; ++i)
            {
                a[i] = rnd.Next(minVal, maxVal);
            }
        }

        // Массивы всегда передаются по ссылке, т.к. являются ссылочными типами!!!
        // !!! ссылка на массив передаётся по ссылке
        static void CreateRandIntArr(ref int[] a, int minVal = -100, int maxVal = 100)
        {
            a = new int[rnd.Next(10, 100)];    // пересоздание фактического параметра (т.е. массив пересоздаётся!!!)

            for (int i = 0; i < a.Length; ++i)
            {
                a[i] = rnd.Next(minVal, maxVal);
            }
        }



        #endregion

        static void InitRandIntMatr(int[,] m, int minVal = 100, int maxVal = 999)
        {
            for (int i = 0; i < m.GetLength(0); ++i)
            {
                for (int j = 0; j < m.GetLength(1); ++j)
                {
                    m[i, j] = rnd.Next(minVal, maxVal);
                }
            }
        }

        static int[,] CreateRandIntMatr(int minVal = 100, int maxVal = 999)
        {
            int[,] retMatr = new int[rnd.Next(10, 20), rnd.Next(10, 20)];

            for (int i = 0; i < retMatr.GetLength(0); ++i)
            {
                for (int j = 0; j < retMatr.GetLength(1); ++j)
                {
                    retMatr[i, j] = rnd.Next(minVal, maxVal);
                }
            }

            return retMatr;
        }

        
        static void PrintArrArr(int[][] arrArr)
        {
            for (int i = 0; i < arrArr.Length; i++)
            {
                for (int j = 0; j < arrArr[i].Length; j++)
                {
                    Console.Write(arrArr[i][j] + " ");
                }
                Console.WriteLine();
            }
        }

        static void PrintArrArr2(int[][] arrArr)
        {
            for (int i = 0; i < arrArr.Length; i++)
            {
                PrintArr(arrArr[i]);    // печать одномерного массива целых чисел

                Console.WriteLine();
            }
        }

        static void PrintArr(int[] arr)
        {
            for (int j = 0; j < arr.Length; j++)
            {
                Console.Write(arr[j] + " ");
            }
        }

        static void Main(string[] args)
        {
            #region --- === ###   Одномерные массивы (векторы)   ### === ---

            // -----------------------------
            //  Одномерные массивы (векторы)
            // -----------------------------

            //// <базовый тип>[] <имя массива> = new <базовый тип>[<размерность>]
            // int[] arr = new int[100];     // объявление массива целых чисел из 100 элементов



            int[] arr1 = new int[] {211, 2, 3};     // объявление массива целых чисел из 3-х элементов
            Console.WriteLine("Прямой порядок");
            foreach (int elem in arr1)
            {
                Console.Write("{0} ", elem);
            }
            Console.WriteLine();
            
            Array.Reverse(arr1);
            Console.WriteLine("Обратный порядок");
            foreach (int elem in arr1)
            {
                Console.Write("{0} ", elem);
            }
            Console.WriteLine();

            Array.Sort(arr1);
            Console.WriteLine("Отсортированный порядок");
            foreach (int elem in arr1)
            {
                Console.Write("{0} ", elem);
            }
            Console.WriteLine();

            Array.Resize(ref arr1, arr1.Length + 1);
            foreach (int elem in arr1)
            {
                Console.Write("{0} ", elem);
            }
            Console.WriteLine();

            Array.Sort(arr1);
            Console.WriteLine("-=-= Отсортированный порядок");
            foreach (int elem in arr1)
            {
                Console.Write("{0} ", elem);
            }
            Console.WriteLine();
            int posZerr = Array.BinarySearch(arr1, 0);
            Console.WriteLine("0's pos =  {0} ", posZerr);

            // --- === Создание поверхностных копий массивов стандартными средствами

            int[] arr1Copy = (int[]) arr1.Clone();    // Создание копии массива
            foreach (int elem in arr1Copy)
            {
                Console.Write("{0} ", elem);
            }
            Console.WriteLine();

            arr1Copy[1] = 100;
            foreach (int elem in arr1)
            {
                Console.Write("{0} ", elem);
            }
            Console.WriteLine();
            foreach (int elem in arr1Copy)
            {
                Console.Write("{0} ", elem);
            }

            int[] arr1Copy2 = new int[arr1.Length];      // Создание массива 
            Array.Copy(arr1, arr1Copy2, arr1.Length);    // Копирование элементов (без пересоздания массива)
            Console.WriteLine();
            foreach (int elem in arr1Copy2)
            {
                Console.Write("{0} ", elem);
            }
            arr1Copy2[0] = 321;
            Console.WriteLine();
            foreach (int elem in arr1)
            {
                Console.Write("{0} ", elem);
            }
            Console.WriteLine();
            foreach (int elem in arr1Copy2)
            {
                Console.Write("{0} ", elem);
            }

            Console.ReadKey();


            //for (int i = 0; i < arr1.Length; ++i)
            //{
            //    Console.WriteLine("arr1[{0}] = {1}", i, arr1[i]);
            //}

            //// Гарантированный доступ к каждому элементу массива
            //// !!! досту только "на чтение"
            //foreach (int elem in arr1)
            //{
            //    Console.WriteLine("elem = {0}", elem);
            //}

            //Console.WriteLine();

            //for (int i = 0; i < arr.Length; ++i)
            //{
            //    arr[i] = i + 1;
            //}

            //foreach (int elem in arr)
            //{
            //    Console.Write("{0} ", elem);
            //}

            //Console.WriteLine();
            //Console.WriteLine();

            //InitRandIntArr(arr);    // 1-й вариант (minVal = -100, maxVal = 100)

            //foreach (int elem in arr)
            //{
            //    Console.Write("{0} ", elem);
            //}

            //Console.WriteLine();
            //Console.WriteLine();

            //InitRandIntArr(arr, 1000, 2000);     // 2-й вариант (minVal = 1000, maxVal = 2000)

            //foreach (int elem in arr)
            //{
            //    Console.Write("{0} ", elem);
            //}

            //Console.WriteLine();
            //Console.WriteLine();


            //CreateRandIntArr(ref arr, -1000);     // 2-й вариант (minVal = -1000, maxVal = 100)

            //foreach (int elem in arr)
            //{
            //    Console.Write("{0} ", elem);
            //}

            #endregion

            #region --- === ###   Многомерные массивы   ### === ---

            // -----------------------------
            //  Многомерные массивы (матрицы)
            // -----------------------------

            //int[,] matr = new int[10, 10];

            //InitRandIntMatr(matr);

            //Console.WriteLine();
            //Console.WriteLine("===============================    =========================");

            //for (int i = 0; i < matr.GetLength(0); ++i)
            //{
            //    for (int j = 0; j < matr.GetLength(1); ++j)
            //    {
            //        Console.Write("{0} ", matr[i, j]);
            //    }
            //    Console.WriteLine();
            //}

            //Console.WriteLine();

            //int[,] matr1 = null;    // пустая ссылка (т.е. массив не инициализирован)

            //matr1 = CreateRandIntMatr();

            //for (int i = 0; i < matr1.GetLength(0); ++i)
            //{
            //    for (int j = 0; j < matr1.GetLength(1); ++j)
            //    {
            //        Console.Write("{0} ", matr1[i, j]);
            //    }
            //    Console.WriteLine();
            //}

            //Console.WriteLine();

            //foreach (int elem in matr1)
            //{
            //    Console.Write("{0} ", elem);
            //}

            //// -----------------------------
            ////        3-хмерные массивы
            //// -----------------------------

            //int[,,] arr3 = new int[10, 10, 10];

            #endregion

            int[][,] arr1001 = new int[10][,];

            int[][] arr100 = new int[10][];    // инициализация массива массивов целых чисел

            for (int i = 0; i < arr100.Length; i++)
            {
                arr100[i] = new int[i+1];  // инициализация массива целых чисел

                for (int j = 0; j < arr100[i].Length; j++)
			    {
                    arr100[i][j] = i * arr100[i].Length + j;
			    }             

            }

            int[][] arr100Copy = (int[][])arr100.Clone();  // Поверхностное копирование!!!
            
            PrintArrArr(arr100);

            foreach (int[] i in arr100)
            {
                foreach (int j in i)
                {
                    Console.Write(j + " ");
                }
                Console.WriteLine();
            }


            int[][] arr101 = arr100;    // копирование ссылки
            arr101[0][0] = 7777;

            PrintArrArr(arr100);

            int[][] arr102 = null;     // !!! пустая ссылка
            arr102 = new int[10][];

            for (int i = 0; i < arr100.Length; i++)
            {
                arr102[i] = arr100[i];    // копирование ссылки
            }
            arr102[1][0] = 7777;

            PrintArrArr(arr100);

            Console.WriteLine();
            Console.WriteLine();


            // Создаёи новую строку с индексом "3" (в исходном массиве ничего не меняется!!!)
            arr102[3] = new int[20];
            for (int j = 0; j < arr102[3].Length; j++)
            {
                arr102[3][j] = j;
            }

            PrintArrArr(arr100);
            PrintArrArr(arr102);
        }
    }
}
