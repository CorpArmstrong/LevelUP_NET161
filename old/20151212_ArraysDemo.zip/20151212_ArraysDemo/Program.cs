﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20151212_ArraysDemo
{
    class Program
    {
        public static Random rnd = new Random();

        #region --- === ###   Одномерные массивы (векторы)   ### === ---

        // Массивы всегда передаются по ссылке, т.к. являются ссылочными типами!!!
        // !!! ссылка на массив передаётся по значению
        static void InitRandIntArr(int[] a, int minVal = -100, int maxVal = 100)
        {
            // Random rnd = new Random();  ошибка
            for (int i = 0; i < a.Length; ++i)
            {
                a[i] = rnd.Next(minVal, maxVal);
            }
        }

        // Массивы всегда передаются по ссылке, т.к. являются ссылочными типами!!!
        // !!! ссылка на массив передаётся по ссылке
        static void CreateRandIntArr(ref int[] a, int minVal = -100, int maxVal = 100)
        {
            a = new int[rnd.Next(10, 100)];    // пересоздание фактического параметра (т.е. массив пересоздаётся!!!)

            for (int i = 0; i < a.Length; ++i)
            {
                a[i] = rnd.Next(minVal, maxVal);
            }
        }


        static int[] CreateRandIntArr1(int minVal = -100, int maxVal = 100)
        {
            int[] a = new int[rnd.Next(10, 100)];    // пересоздание фактического параметра (т.е. массив пересоздаётся!!!)

            for (int i = 0; i < a.Length; ++i)
            {
                a[i] = rnd.Next(minVal, maxVal);
            }

            return a;
        }

        #endregion

        static void InitRandIntMatr(int[,] m, int minVal = 100, int maxVal = 999)
        {
            for (int i = 0; i < m.GetLength(0); ++i)
            {
                for (int j = 0; j < m.GetLength(1); ++j)
                {
                    m[i, j] = rnd.Next(minVal, maxVal);
                }
            }
        }

        static int[,] CreateRandIntMatr(int minVal = 100, int maxVal = 999)
        {
            int[,] retMatr = new int[rnd.Next(10, 20), rnd.Next(10, 20)];

            for (int i = 0; i < retMatr.GetLength(0); ++i)
            {
                for (int j = 0; j < retMatr.GetLength(1); ++j)
                {
                    retMatr[i, j] = rnd.Next(minVal, maxVal);
                }
            }

            return retMatr;
        }

        static void Main(string[] args)
        {
            #region --- === ###   Одномерные массивы (векторы)   ### === ---

            // -----------------------------
            //  Одномерные массивы (векторы)
            // -----------------------------

            int[] arr11;  // ??? объявление ссылки на массив (по-умолчанию содержит пустую ссылку null)
            int[] arr12 = null;

            // <базовый тип>[] <имя массива> = new <базовый тип>[<размерность>]
            int[] arr = new int[100];     // объявление массива целых чисел из 100 элементов
            int[] arr1 = new int[] {1, 2, 3};     // объявление массива целых чисел из 3-х элементов

            for (int i = 0; i < arr.Length; ++i)
            {
                Console.Write("arr[{0}] = {1} ", i, arr[i]);
            }

            for (int i = 0; i < arr1.Length; ++i)
            {
                Console.WriteLine("arr1[{0}] = {1} ", i, arr1[i]);
            }

            // Гарантированный доступ к каждому элементу массива
            // !!! досту только "на чтение"
            foreach (int elem in arr1)
            {
                Console.WriteLine("elem = {0}", elem);
            }

            Console.WriteLine();

            for (int i = 0; i < arr.Length; ++i)
            {
                arr[i] = i + 1;
            }

            foreach (int elem in arr)
            {
                Console.Write("{0} ", elem);
            }

            Console.WriteLine();
            Console.WriteLine();

            InitRandIntArr(arr);    // 1-й вариант (minVal = -100, maxVal = 100)

            foreach (int elem in arr)
            {
                Console.Write("{0,4} ", elem);
            }

            Console.WriteLine();
            Console.WriteLine();

            InitRandIntArr(arr, 1000, 2000);     // 2-й вариант (minVal = 1000, maxVal = 2000)

            foreach (int elem in arr)
            {
                Console.Write("{0,5}", elem);
            }

            Console.WriteLine();
            Console.WriteLine();


            CreateRandIntArr(ref arr12, -1000);     // 2-й вариант (minVal = -1000, maxVal = 100)

            foreach (int elem in arr12)
            {
                Console.Write("{0} ", elem);
            }

            #endregion

            #region --- === ###   Многомерные массивы   ### === ---

            // -----------------------------
            //  Многомерные массивы (матрицы)
            // -----------------------------

            int[,] matr = new int[10, 10];

            InitRandIntMatr(matr);

            Console.WriteLine();
            Console.WriteLine("===============================    =========================");

            for (int i = 0; i < matr.GetLength(0); ++i)
            {
                for (int j = 0; j < matr.GetLength(1); ++j)
                {
                    Console.Write("{0} ", matr[i, j]);
                }
                Console.WriteLine();
            }

            Console.WriteLine();

            int[,] matr1 = null;    // пустая ссылка (т.е. массив не инициализирован)

            matr1 = CreateRandIntMatr();

            for (int i = 0; i < matr1.GetLength(0); ++i)
            {
                for (int j = 0; j < matr1.GetLength(1); ++j)
                {
                    Console.Write("{0} ", matr1[i, j]);
                }
                Console.WriteLine();
            }

            Console.WriteLine();

            foreach (int elem in matr1)
            {
                Console.Write("{0} ", elem);
            }

            // -----------------------------
            //        3-хмерные массивы
            // -----------------------------

            int[,,] arr3 = new int[10, 10, 10];

            #endregion
        }
    }
}
